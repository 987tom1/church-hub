import type { Container } from '../container';
import { hashPassword } from '../utils/crypto';
import { newId } from '../utils/id';
import { nowISO } from '../utils/date';
import type { User } from '../core/entities/user';
import type { Church } from '../core/entities/church';
import type { Registrant } from '../core/entities/registrant';
import type { Camper } from '../core/entities/camper';
import type { AccommodationBlock } from '../core/entities/accommodation';
import type { Zone } from '../core/entities/zone';
import type { FaqItem } from '../core/entities/content';
import type { ScheduleItem } from '../core/entities/schedule';
import type { Devotional } from '../core/entities/devotional';
import type { Notification } from '../core/entities/notification';
import type { CampSettings } from '../core/entities/settings';
import { SETTINGS_ID } from '../core/entities/settings';
import type { ConsentType } from '../core/types/enums';
import { CONSENT_TYPES } from '../core/types/enums';
import { createLogger } from '../utils/logger';

const logger = createLogger('seed');

function defaultConsents(): Camper['consents'] {
  const result = {} as Record<ConsentType, { granted: boolean; timestamp: string | null }>;
  for (const t of CONSENT_TYPES) {
    result[t] = { granted: false, timestamp: null };
  }
  return result;
}

const DEMO_PASSWORD = 'demo1234';

export async function seedAll(container: Container): Promise<void> {
  const { repos } = container;

  // Don't re-seed if data already exists
  const existingUsers = await repos.users.findAll();
  if (existingUsers.length > 0) {
    logger.info('Seed data already present — skipping');
    return;
  }

  logger.info('Seeding demo data...');
  const now = nowISO();
  const pw = await hashPassword(DEMO_PASSWORD);

  // ----------------------------------------------------------------
  // Churches
  // ----------------------------------------------------------------
  const victoryId = newId('church');
  const gracePtId = newId('church');
  const riverbendId = newId('church');

  const churches: Church[] = [
    {
      id: victoryId,
      name: 'Victory Church',
      zone: 'Yellow',
      code: 'VIC',
      selfRegisterSlug: 'victory',
      expectedCount: 22,
      youthPastorName: 'Mark Thompson',
      contactEmail: 'mark@victory.church',
      contactPhone: '0412 345 678',
      reservations: [],
      contacts: {
        male: {
          primary: { name: 'Mark Thompson', phone: '0412 345 678' },
          backup: { name: 'James Lee', phone: '0400 111 222' },
        },
        female: {
          primary: { name: 'Sarah Thompson', phone: '0413 222 333' },
          backup: { name: 'Emily Wong', phone: '0402 444 555' },
        },
      },
      createdAt: now,
      updatedAt: now,
    },
    {
      id: gracePtId,
      name: 'Grace Point Church',
      zone: 'Blue',
      code: 'GPC',
      selfRegisterSlug: 'grace-point',
      expectedCount: 18,
      youthPastorName: 'David Kim',
      contactEmail: 'david@gracepoint.org',
      contactPhone: '0422 987 654',
      reservations: [],
      contacts: {
        male: {
          primary: { name: 'David Kim', phone: '0422 987 654' },
          backup: { name: 'Nathan Park', phone: '0433 876 543' },
        },
        female: {
          primary: { name: 'Jenny Kim', phone: '0411 765 432' },
          backup: { name: 'Lisa Park', phone: '0444 321 098' },
        },
      },
      createdAt: now,
      updatedAt: now,
    },
    {
      id: riverbendId,
      name: 'Riverbend Community',
      zone: 'Green',
      code: 'RBC',
      selfRegisterSlug: 'riverbend',
      expectedCount: 15,
      youthPastorName: 'Chris Brown',
      contactEmail: 'chris@riverbend.com',
      contactPhone: '0455 666 777',
      reservations: [],
      contacts: {
        male: {
          primary: { name: 'Chris Brown', phone: '0455 666 777' },
          backup: { name: 'Tom Wilson', phone: '0466 888 999' },
        },
        female: {
          primary: { name: 'Amy Brown', phone: '0477 123 456' },
          backup: { name: 'Rachel Wilson', phone: '0488 987 654' },
        },
      },
      createdAt: now,
      updatedAt: now,
    },
  ];
  for (const c of churches) await repos.churches.save(c);

  // ----------------------------------------------------------------
  // Zones
  // ----------------------------------------------------------------
  const zones: Zone[] = [
    { id: newId('zone'), name: 'Yellow', label: 'Yellow Zone', colorHex: '#EAB308', leaderIds: [], createdAt: now, updatedAt: now },
    { id: newId('zone'), name: 'Blue', label: 'Blue Zone', colorHex: '#3B82F6', leaderIds: [], createdAt: now, updatedAt: now },
    { id: newId('zone'), name: 'Green', label: 'Green Zone', colorHex: '#22C55E', leaderIds: [], createdAt: now, updatedAt: now },
    { id: newId('zone'), name: 'Red', label: 'Red Zone', colorHex: '#EF4444', leaderIds: [], createdAt: now, updatedAt: now },
  ];
  for (const z of zones) await repos.zones.save(z);

  // ----------------------------------------------------------------
  // Users — demo accounts
  // ----------------------------------------------------------------
  const users: User[] = [
    // Shared church accounts — one per church, used for both pre-camp and at-camp
    {
      id: newId('user'),
      firstName: 'Victory',
      lastName: 'Church',
      email: 'victory@campplatform.org',
      role: 'church',
      churchId: victoryId,
      churchName: 'Victory Church',
      zone: 'Yellow',
      status: 'active',
      passwordHash: pw,
      createdAt: now,
      updatedAt: now,
    },
    {
      id: newId('user'),
      firstName: 'Grace Point',
      lastName: 'Church',
      email: 'gracepoint@campplatform.org',
      role: 'church',
      churchId: gracePtId,
      churchName: 'Grace Point Church',
      zone: 'Blue',
      status: 'active',
      passwordHash: pw,
      createdAt: now,
      updatedAt: now,
    },
    {
      id: newId('user'),
      firstName: 'Riverbend',
      lastName: 'Community',
      email: 'riverbend@campplatform.org',
      role: 'church',
      churchId: riverbendId,
      churchName: 'Riverbend Community',
      zone: 'Green',
      status: 'active',
      passwordHash: pw,
      createdAt: now,
      updatedAt: now,
    },
    {
      id: newId('user'),
      firstName: 'Camp',
      lastName: 'Director',
      email: 'director@campplatform.org',
      role: 'director',
      churchId: null,
      churchName: null,
      zone: null,
      status: 'active',
      passwordHash: pw,
      createdAt: now,
      updatedAt: now,
    },
    {
      id: newId('user'),
      firstName: 'Platform',
      lastName: 'Admin',
      email: 'admin@campplatform.org',
      role: 'admin',
      churchId: null,
      churchName: null,
      zone: null,
      status: 'active',
      passwordHash: pw,
      createdAt: now,
      updatedAt: now,
    },
    {
      id: newId('user'),
      firstName: 'Zone',
      lastName: 'Leader',
      email: 'api@campplatform.org',
      role: 'zoneLeader',
      churchId: null,
      churchName: null,
      zone: 'Yellow',
      status: 'active',
      passwordHash: pw,
      createdAt: now,
      updatedAt: now,
    },
    // Additional zone leaders
    {
      id: newId('user'),
      firstName: 'Blue',
      lastName: 'Leader',
      email: 'blue.leader@campplatform.org',
      role: 'zoneLeader',
      churchId: null,
      churchName: null,
      zone: 'Blue',
      status: 'active',
      passwordHash: pw,
      createdAt: now,
      updatedAt: now,
    },
    {
      id: newId('user'),
      firstName: 'Green',
      lastName: 'Leader',
      email: 'green.leader@campplatform.org',
      role: 'zoneLeader',
      churchId: null,
      churchName: null,
      zone: 'Green',
      status: 'active',
      passwordHash: pw,
      createdAt: now,
      updatedAt: now,
    },
  ];
  for (const u of users) await repos.users.save(u);

  // ----------------------------------------------------------------
  // Accommodation blocks
  // ----------------------------------------------------------------
  const blocks: AccommodationBlock[] = [
    {
      id: newId('block'),
      kind: 'tent',
      name: 'Campsite A',
      price: 250,
      capacity: 80,
      baseTaken: 12,
      createdAt: now,
      updatedAt: now,
    },
    {
      id: newId('block'),
      kind: 'classroom',
      name: 'Classroom Block 1',
      price: 200,
      capacity: 40,
      baseTaken: 5,
      createdAt: now,
      updatedAt: now,
    },
  ];
  for (const b of blocks) await repos.accommodation.save(b);

  // ----------------------------------------------------------------
  // Registrants (pre-camp, Hub model)
  // ----------------------------------------------------------------
  const registrantData: Array<Omit<Registrant, 'id' | 'createdAt' | 'updatedAt'>> = [
    // Victory Church
    { firstName: 'Jake', lastName: 'Smith', gender: 'male', kind: 'camper', grade: 10, churchId: victoryId, churchName: 'Victory Church', zone: 'Yellow', paymentStatus: 'paid', blueCardCollected: false, status: 'registered' },
    { firstName: 'Emma', lastName: 'Jones', gender: 'female', kind: 'camper', grade: 9, churchId: victoryId, churchName: 'Victory Church', zone: 'Yellow', paymentStatus: 'deposit', blueCardCollected: false, status: 'registered' },
    { firstName: 'Liam', lastName: 'Brown', gender: 'male', kind: 'camper', grade: 11, churchId: victoryId, churchName: 'Victory Church', zone: 'Yellow', paymentStatus: 'unpaid', blueCardCollected: false, status: 'registered' },
    { firstName: 'Sofia', lastName: 'Davis', gender: 'female', kind: 'camper', grade: 8, churchId: victoryId, churchName: 'Victory Church', zone: 'Yellow', paymentStatus: 'paid', blueCardCollected: false, status: 'registered' },
    { firstName: 'Mark', lastName: 'Thompson', gender: 'male', kind: 'leader', churchId: victoryId, churchName: 'Victory Church', zone: 'Yellow', paymentStatus: 'paid', blueCardCollected: true, status: 'registered' },
    { firstName: 'Sarah', lastName: 'Thompson', gender: 'female', kind: 'leader', churchId: victoryId, churchName: 'Victory Church', zone: 'Yellow', paymentStatus: 'paid', blueCardCollected: false, status: 'registered' },
    // Grace Point
    { firstName: 'Noah', lastName: 'Wilson', gender: 'male', kind: 'camper', grade: 12, churchId: gracePtId, churchName: 'Grace Point Church', zone: 'Blue', paymentStatus: 'paid', blueCardCollected: false, status: 'registered' },
    { firstName: 'Olivia', lastName: 'Taylor', gender: 'female', kind: 'camper', grade: 10, churchId: gracePtId, churchName: 'Grace Point Church', zone: 'Blue', paymentStatus: 'unpaid', blueCardCollected: false, status: 'registered' },
    { firstName: 'Ethan', lastName: 'Anderson', gender: 'male', kind: 'camper', grade: 9, churchId: gracePtId, churchName: 'Grace Point Church', zone: 'Blue', paymentStatus: 'deposit', blueCardCollected: false, status: 'registered' },
    { firstName: 'David', lastName: 'Kim', gender: 'male', kind: 'leader', churchId: gracePtId, churchName: 'Grace Point Church', zone: 'Blue', paymentStatus: 'paid', blueCardCollected: true, status: 'registered' },
    // Riverbend
    { firstName: 'Ava', lastName: 'Martin', gender: 'female', kind: 'camper', grade: 7, churchId: riverbendId, churchName: 'Riverbend Community', zone: 'Green', paymentStatus: 'paid', blueCardCollected: false, status: 'registered' },
    { firstName: 'Mason', lastName: 'Garcia', gender: 'male', kind: 'camper', grade: 8, churchId: riverbendId, churchName: 'Riverbend Community', zone: 'Green', paymentStatus: 'unpaid', blueCardCollected: false, status: 'registered' },
    { firstName: 'Isabella', lastName: 'White', gender: 'female', kind: 'camper', grade: 11, churchId: riverbendId, churchName: 'Riverbend Community', zone: 'Green', paymentStatus: 'paid', blueCardCollected: false, status: 'registered' },
    { firstName: 'Chris', lastName: 'Brown', gender: 'male', kind: 'leader', churchId: riverbendId, churchName: 'Riverbend Community', zone: 'Green', paymentStatus: 'paid', blueCardCollected: true, status: 'registered' },
    { firstName: 'Amy', lastName: 'Brown', gender: 'female', kind: 'leader', churchId: riverbendId, churchName: 'Riverbend Community', zone: 'Green', paymentStatus: 'deposit', blueCardCollected: false, status: 'registered' },
    { firstName: 'Tom', lastName: 'Wilson', gender: 'male', kind: 'leader', churchId: riverbendId, churchName: 'Riverbend Community', zone: 'Green', paymentStatus: 'unpaid', blueCardCollected: false, status: 'registered' },
  ];

  for (const r of registrantData) {
    await repos.registrants.save({ id: newId('reg'), ...r, createdAt: now, updatedAt: now });
  }

  // ----------------------------------------------------------------
  // Campers (at-camp, Portal model)
  // ----------------------------------------------------------------
  const camperData: Array<Omit<Camper, 'id' | 'createdAt' | 'updatedAt' | 'checkInHistory' | 'signOutHistory'>> = [
    {
      firstName: 'Jake', lastName: 'Smith', gender: 'male', dateOfBirth: '2009-03-15', grade: 10,
      zone: 'Yellow', kind: 'student', churchId: victoryId, churchName: 'Victory Church',
      medicalConditions: [], dietaryRequirements: [], consents: defaultConsents(),
      atCamp: false, status: 'registered', mobile: null, email: null, suburb: null, postcode: null, state: null,
      groupId: null, school: 'Brisbane State High', otherMedications: null,
      parentGuardianName: 'Peter Smith', parentPhone: '0411 222 333', parentRelation: 'Father',
      blueCardNumber: null, blueCardExpiry: null,
    },
    {
      firstName: 'Emma', lastName: 'Jones', gender: 'female', dateOfBirth: '2010-07-20', grade: 9,
      zone: 'Yellow', kind: 'student', churchId: victoryId, churchName: 'Victory Church',
      medicalConditions: ['Asthma'], dietaryRequirements: ['Vegetarian'], consents: defaultConsents(),
      atCamp: false, status: 'registered', mobile: null, email: null, suburb: null, postcode: null, state: null,
      groupId: null, school: 'Sunnybank Hills SHS', otherMedications: 'Ventolin as needed',
      parentGuardianName: 'Helen Jones', parentPhone: '0422 333 444', parentRelation: 'Mother',
      blueCardNumber: null, blueCardExpiry: null,
    },
    {
      firstName: 'Liam', lastName: 'Brown', gender: 'male', dateOfBirth: '2008-11-05', grade: 11,
      zone: 'Yellow', kind: 'student', churchId: victoryId, churchName: 'Victory Church',
      medicalConditions: [], dietaryRequirements: [], consents: defaultConsents(),
      atCamp: false, status: 'registered', mobile: null, email: null, suburb: null, postcode: null, state: null,
      groupId: null, school: null, otherMedications: null,
      parentGuardianName: 'Robert Brown', parentPhone: '0433 555 666', parentRelation: 'Father',
      blueCardNumber: null, blueCardExpiry: null,
    },
    {
      firstName: 'Noah', lastName: 'Wilson', gender: 'male', dateOfBirth: '2007-05-12', grade: 12,
      zone: 'Blue', kind: 'student', churchId: gracePtId, churchName: 'Grace Point Church',
      medicalConditions: ['Peanut allergy'], dietaryRequirements: ['Nut-free'], consents: defaultConsents(),
      atCamp: false, status: 'registered', mobile: null, email: null, suburb: null, postcode: null, state: null,
      groupId: null, school: 'Capalaba State College', otherMedications: 'EpiPen',
      parentGuardianName: 'Susan Wilson', parentPhone: '0444 777 888', parentRelation: 'Mother',
      blueCardNumber: null, blueCardExpiry: null,
    },
    {
      firstName: 'Olivia', lastName: 'Taylor', gender: 'female', dateOfBirth: '2009-09-30', grade: 10,
      zone: 'Blue', kind: 'student', churchId: gracePtId, churchName: 'Grace Point Church',
      medicalConditions: [], dietaryRequirements: ['Gluten-free'], consents: defaultConsents(),
      atCamp: false, status: 'registered', mobile: null, email: null, suburb: null, postcode: null, state: null,
      groupId: null, school: null, otherMedications: null,
      parentGuardianName: 'Mike Taylor', parentPhone: '0455 999 000', parentRelation: 'Father',
      blueCardNumber: null, blueCardExpiry: null,
    },
    {
      firstName: 'Ethan', lastName: 'Anderson', gender: 'male', dateOfBirth: '2010-02-18', grade: 9,
      zone: 'Blue', kind: 'student', churchId: gracePtId, churchName: 'Grace Point Church',
      medicalConditions: [], dietaryRequirements: [], consents: defaultConsents(),
      atCamp: false, status: 'registered', mobile: null, email: null, suburb: null, postcode: null, state: null,
      groupId: null, school: null, otherMedications: null,
      parentGuardianName: 'Lisa Anderson', parentPhone: '0466 111 222', parentRelation: 'Mother',
      blueCardNumber: null, blueCardExpiry: null,
    },
    {
      firstName: 'Ava', lastName: 'Martin', gender: 'female', dateOfBirth: '2012-06-25', grade: 7,
      zone: 'Green', kind: 'student', churchId: riverbendId, churchName: 'Riverbend Community',
      medicalConditions: [], dietaryRequirements: [], consents: defaultConsents(),
      atCamp: false, status: 'registered', mobile: null, email: null, suburb: null, postcode: null, state: null,
      groupId: null, school: null, otherMedications: null,
      parentGuardianName: 'John Martin', parentPhone: '0477 333 444', parentRelation: 'Father',
      blueCardNumber: null, blueCardExpiry: null,
    },
    {
      firstName: 'Mason', lastName: 'Garcia', gender: 'male', dateOfBirth: '2011-10-14', grade: 8,
      zone: 'Green', kind: 'student', churchId: riverbendId, churchName: 'Riverbend Community',
      medicalConditions: ['Hay fever'], dietaryRequirements: [], consents: defaultConsents(),
      atCamp: false, status: 'registered', mobile: null, email: null, suburb: null, postcode: null, state: null,
      groupId: null, school: null, otherMedications: 'Antihistamine daily',
      parentGuardianName: 'Maria Garcia', parentPhone: '0488 555 666', parentRelation: 'Mother',
      blueCardNumber: null, blueCardExpiry: null,
    },
    {
      firstName: 'Isabella', lastName: 'White', gender: 'female', dateOfBirth: '2008-04-08', grade: 11,
      zone: 'Green', kind: 'student', churchId: riverbendId, churchName: 'Riverbend Community',
      medicalConditions: [], dietaryRequirements: ['Vegan'], consents: defaultConsents(),
      atCamp: false, status: 'registered', mobile: null, email: null, suburb: null, postcode: null, state: null,
      groupId: null, school: null, otherMedications: null,
      parentGuardianName: 'George White', parentPhone: '0499 777 888', parentRelation: 'Father',
      blueCardNumber: null, blueCardExpiry: null,
    },
    // Leaders as campers
    {
      firstName: 'Mark', lastName: 'Thompson', gender: 'male', dateOfBirth: '1985-01-01', grade: null,
      zone: 'Yellow', kind: 'leader', churchId: victoryId, churchName: 'Victory Church',
      medicalConditions: [], dietaryRequirements: [], consents: defaultConsents(),
      atCamp: true, status: 'checked_in', mobile: '0412 345 678', email: 'mark@victory.church',
      suburb: null, postcode: null, state: null, groupId: null, school: null, otherMedications: null,
      parentGuardianName: null, parentPhone: null, parentRelation: null,
      blueCardNumber: 'BC-123456', blueCardExpiry: '2026-12-31',
    },
    {
      firstName: 'David', lastName: 'Kim', gender: 'male', dateOfBirth: '1982-05-15', grade: null,
      zone: 'Blue', kind: 'leader', churchId: gracePtId, churchName: 'Grace Point Church',
      medicalConditions: [], dietaryRequirements: [], consents: defaultConsents(),
      atCamp: true, status: 'checked_in', mobile: '0422 987 654', email: 'david@gracepoint.org',
      suburb: null, postcode: null, state: null, groupId: null, school: null, otherMedications: null,
      parentGuardianName: null, parentPhone: null, parentRelation: null,
      blueCardNumber: 'BC-234567', blueCardExpiry: '2027-06-30',
    },
  ];

  for (const c of camperData) {
    await repos.campers.save({ id: newId('camper'), ...c, checkInHistory: [], signOutHistory: [], createdAt: now, updatedAt: now });
  }

  // ----------------------------------------------------------------
  // FAQ items
  // ----------------------------------------------------------------
  const faqs: Array<Omit<FaqItem, 'id' | 'createdAt' | 'updatedAt'>> = [
    { question: 'What should I bring to camp?', answer: 'Bible, sleeping bag, pillow, toiletries, comfortable clothing, closed-toe shoes, water bottle, sunscreen, and any prescribed medication.', order: 1 },
    { question: 'Is there phone/internet access?', answer: 'Phone use is discouraged during sessions. There is limited WiFi for leaders only in the admin area.', order: 2 },
    { question: 'What is the drop-off time?', answer: 'Drop-off is from 3:00 PM on Tuesday. Please do not arrive before this time as camp setup will still be underway.', order: 3 },
    { question: 'What is the pick-up time?', answer: 'Pick-up is from 12:30 PM on Thursday after the closing ceremony. Please arrange to collect your child promptly.', order: 4 },
    { question: 'Are there medical staff on site?', answer: 'Yes, we have a qualified first aider on site at all times. For medical emergencies, the nearest hospital is 20 minutes away.', order: 5 },
    { question: 'What if my child has dietary requirements?', answer: 'Please ensure dietary requirements are recorded during registration. The kitchen caters for vegetarian, vegan, gluten-free, and common allergies. Contact us for severe allergies.', order: 6 },
  ];

  for (const f of faqs) {
    await repos.faqs.save({ id: newId('faq'), ...f, createdAt: now, updatedAt: now });
  }

  // ----------------------------------------------------------------
  // Schedule (Tue/Wed/Thu)
  // ----------------------------------------------------------------
  const scheduleItems: Array<Omit<ScheduleItem, 'id' | 'createdAt' | 'updatedAt'>> = [
    // Monday — arrival day: one afternoon check-in only
    { day: '2026-07-06', startTime: '11:00', endTime: '13:00', title: 'Arrivals & Registration', location: 'Main Gate', type: 'logistics', isCheckInPoint: false },
    { day: '2026-07-06', startTime: '13:00', endTime: '13:15', title: 'Afternoon Check-in', location: 'Main Hall', type: 'session', isCheckInPoint: true },
    { day: '2026-07-06', startTime: '13:15', endTime: '14:30', title: 'Lunch', location: 'Dining Hall', type: 'meal', isCheckInPoint: false },
    { day: '2026-07-06', startTime: '19:00', endTime: '21:00', title: 'Opening Night Session', location: 'Main Hall', type: 'session', isCheckInPoint: false },
    { day: '2026-07-06', startTime: '21:30', endTime: null, title: 'Lights Out', location: null, type: 'logistics', isCheckInPoint: false },
    // Tuesday — two check-ins
    { day: '2026-07-07', startTime: '07:30', endTime: '08:30', title: 'Breakfast', location: 'Dining Hall', type: 'meal', isCheckInPoint: false },
    { day: '2026-07-07', startTime: '09:00', endTime: '09:15', title: 'Morning Check-in', location: 'Main Hall', type: 'session', isCheckInPoint: true },
    { day: '2026-07-07', startTime: '09:15', endTime: '10:30', title: 'Morning Session', location: 'Main Hall', type: 'session', isCheckInPoint: false },
    { day: '2026-07-07', startTime: '12:00', endTime: '13:00', title: 'Lunch', location: 'Dining Hall', type: 'meal', isCheckInPoint: false },
    { day: '2026-07-07', startTime: '13:30', endTime: '15:30', title: 'Zone Activities', location: 'Oval', type: 'activity', isCheckInPoint: false },
    { day: '2026-07-07', startTime: '17:00', endTime: '17:15', title: 'Afternoon Check-in', location: 'Main Hall', type: 'session', isCheckInPoint: true },
    { day: '2026-07-07', startTime: '17:15', endTime: '18:15', title: 'Dinner', location: 'Dining Hall', type: 'meal', isCheckInPoint: false },
    { day: '2026-07-07', startTime: '19:30', endTime: '21:30', title: 'Evening Session', location: 'Main Hall', type: 'session', isCheckInPoint: false },
    { day: '2026-07-07', startTime: '21:30', endTime: null, title: 'Lights Out', location: null, type: 'logistics', isCheckInPoint: false },
    // Wednesday — two check-ins
    { day: '2026-07-08', startTime: '07:30', endTime: '08:30', title: 'Breakfast', location: 'Dining Hall', type: 'meal', isCheckInPoint: false },
    { day: '2026-07-08', startTime: '09:00', endTime: '09:15', title: 'Morning Check-in', location: 'Main Hall', type: 'session', isCheckInPoint: true },
    { day: '2026-07-08', startTime: '09:15', endTime: '10:30', title: 'Morning Session', location: 'Main Hall', type: 'session', isCheckInPoint: false },
    { day: '2026-07-08', startTime: '12:00', endTime: '13:00', title: 'Lunch', location: 'Dining Hall', type: 'meal', isCheckInPoint: false },
    { day: '2026-07-08', startTime: '13:30', endTime: '15:30', title: 'Free Time', location: null, type: 'free', isCheckInPoint: false },
    { day: '2026-07-08', startTime: '17:00', endTime: '17:15', title: 'Afternoon Check-in', location: 'Main Hall', type: 'session', isCheckInPoint: true },
    { day: '2026-07-08', startTime: '17:15', endTime: '18:15', title: 'Dinner', location: 'Dining Hall', type: 'meal', isCheckInPoint: false },
    { day: '2026-07-08', startTime: '19:30', endTime: '21:30', title: 'Evening Session', location: 'Main Hall', type: 'session', isCheckInPoint: false },
    { day: '2026-07-08', startTime: '21:30', endTime: null, title: 'Lights Out', location: null, type: 'logistics', isCheckInPoint: false },
    // Thursday — departure day: one morning check-in only
    { day: '2026-07-09', startTime: '07:30', endTime: '08:30', title: 'Breakfast', location: 'Dining Hall', type: 'meal', isCheckInPoint: false },
    { day: '2026-07-09', startTime: '09:00', endTime: '09:15', title: 'Morning Check-in', location: 'Main Hall', type: 'session', isCheckInPoint: true },
    { day: '2026-07-09', startTime: '09:15', endTime: '10:30', title: 'Final Session', location: 'Main Hall', type: 'session', isCheckInPoint: false },
    { day: '2026-07-09', startTime: '11:00', endTime: '12:00', title: 'Closing Ceremony', location: 'Main Hall', type: 'session', isCheckInPoint: false },
    { day: '2026-07-09', startTime: '12:30', endTime: null, title: 'Departures', location: 'Main Gate', type: 'logistics', isCheckInPoint: false },
  ];

  for (const s of scheduleItems) {
    await repos.schedule.save({ id: newId('sched'), ...s, createdAt: now, updatedAt: now });
  }

  // ----------------------------------------------------------------
  // Devotional (Wednesday)
  // ----------------------------------------------------------------
  const devotional: Devotional = {
    id: newId('dev'),
    day: '2026-07-08',
    verse: 'Do not conform to the pattern of this world, but be transformed by the renewing of your mind.',
    reference: 'Romans 12:2',
    reflection: 'God calls us to a different standard. As young people, you face enormous pressure to fit in with the world around you — social media, peer pressure, cultural trends. But Paul\'s challenge is radical: don\'t be squeezed into the world\'s mould. Instead, let God reshape your thinking from the inside out. Transformation starts in the mind. What we dwell on, what we consume, what we believe — these things shape who we become.',
    prayer: 'Father, thank you that you don\'t just want to change our behaviour — you want to transform our whole minds. Help us today to choose your truth over the world\'s lies. Renew our thinking so that we can discern your good and perfect will. Amen.',
    createdAt: now,
    updatedAt: now,
  };
  await repos.devotionals.save(devotional);

  // ----------------------------------------------------------------
  // Notifications
  // ----------------------------------------------------------------
  const notifications: Notification[] = [
    {
      id: newId('notif'),
      scope: 'camp',
      zone: null,
      churchId: null,
      priority: 'normal',
      title: 'Welcome to Camp 2026!',
      body: 'We\'re so glad you\'re here! Please make sure you\'ve collected your lanyard and camp pack from the registration desk. See you at Opening Night at 7pm!',
      senderId: 'seed',
      senderName: 'Camp Director',
      senderRole: 'director',
      audienceEstimate: 55,
      expiresAt: null,
      createdAt: now,
    },
    {
      id: newId('notif'),
      scope: 'zone',
      zone: 'Yellow',
      churchId: null,
      priority: 'normal',
      title: 'Yellow Zone: Meeting Point',
      body: 'Yellow Zone, your meeting point for zone activities is the northern oval. Look for the yellow flag! Zone leader will be there from 10:30am.',
      senderId: 'seed',
      senderName: 'Zone Leader',
      senderRole: 'zoneLeader',
      audienceEstimate: 22,
      expiresAt: null,
      createdAt: now,
    },
    {
      id: newId('notif'),
      scope: 'camp',
      zone: null,
      churchId: null,
      priority: 'urgent',
      title: 'Weather Advisory',
      body: 'Afternoon thunderstorms expected around 2pm. All outdoor activities will be moved indoors. Leaders please keep your groups together and check the updated schedule.',
      senderId: 'seed',
      senderName: 'Camp Director',
      senderRole: 'director',
      audienceEstimate: 55,
      expiresAt: null,
      createdAt: now,
    },
  ];
  for (const n of notifications) await repos.notifications.save(n);

  // ----------------------------------------------------------------
  // Camp Settings
  // ----------------------------------------------------------------
  const settings: CampSettings = {
    id: SETTINGS_ID,
    campName: 'Winter Youth Camp 2026',
    year: 2026,
    startDate: '2026-07-06',
    endDate: '2026-07-09',
    timezone: 'Australia/Brisbane',
    checkInLocation: 'Main Gate, Camp Arawang',
    checkInFrom: '15:00',
    checkInBanner: 'Arrivals from 3:00 PM Tuesday 7 July. Please do not arrive before this time.',
    registerBaseUrl: 'https://camp.example.org/register',
    checkInDays: ['2026-07-06', '2026-07-07', '2026-07-08', '2026-07-09'],
    accommodationLocked: false,
    campMode: 'pre-camp',
    createdAt: now,
    updatedAt: now,
  };
  await repos.settings.saveSingleton(settings);

  logger.info('Seed complete. Demo accounts (password: demo1234):');
  logger.info('  mark@campplatform.org — youthPastor (Victory)');
  logger.info('  director@campplatform.org — director');
  logger.info('  admin@campplatform.org — admin');
  logger.info('  victory@campplatform.org — church (Victory)');
  logger.info('  api@campplatform.org — zoneLeader (Yellow)');
}
